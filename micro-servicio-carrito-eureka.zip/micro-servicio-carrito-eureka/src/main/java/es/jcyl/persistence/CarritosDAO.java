package es.jcyl.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.jcyl.models.Carrito;

// Si quiero exponer este DAO como servicio REST
@RepositoryRestResource(path = "carritos")
public interface CarritosDAO extends MongoRepository<Carrito, String>{
	
	// Ver todos los carritos
	// http://localhost:8003/carritos
	
	// Buscar un carrito por el id
	// http://localhost:8003/carritos/hbjhbjhgvhgvhk
	
	// Buscar un carrito por el usuario
	// http://localhost:8003/carritos/search/findByUsuario?usuario=Pepe
	
	public Carrito findByUsuario(String usuario);

}
