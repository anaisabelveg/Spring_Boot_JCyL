package es.jcyl.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.jcyl.clients.PedidosClienteFeign;
import es.jcyl.models.Carrito;
import es.jcyl.models.Pedido;
import es.jcyl.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		// Solo creamos el carrito en el caso de que no exista otro para ese usuario
		Carrito carrito = consultar(usuario);
		
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		Pedido pedido = clienteFeign.crear(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importePedido = pedido.getProducto().getPrecio() * cantidad;
		carrito.setImporte(carrito.getImporte() + importePedido);
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		// Solo borro el primer pedido que encuentre con ese id de producto
		Pedido encontrado = contenido.stream()
								.filter(ped -> ped.getProducto().getId() == id)
								.findFirst()
								.get();
		
		contenido.remove(encontrado);
		
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		return dao.save(carrito);
	}

}
