package es.jcyl.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import es.jcyl.business.ICarritoBS;
import es.jcyl.models.Carrito;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoBS bs;

	// (método Post) http://localhost:8003/crear/Pepito
	@PostMapping("/crear/{usuario}")
	Carrito crear(@PathVariable String usuario) {
		return bs.crear(usuario);
	}

	// (método PUT) http://localhost:8003/agregar/id/3/cantidad/100/usuario/Pepito
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	Carrito agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, @PathVariable String usuario) {
		return bs.agregarPedido(id, cantidad, usuario);
	}

	// (método GET)  http://localhost:8003/consultar/Pepito
	@GetMapping("/consultar/{usuario}")
	Carrito consultar(@PathVariable String usuario) {
		return bs.consultar(usuario);
	}

	// (método DELETE)  http://localhost:8003/eliminar/id/3/usuario/Pepito
	@DeleteMapping("/eliminar/id/{id}/usuario/{usuario}")
	Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		return bs.eliminarPedido(id, usuario);
	}

}
