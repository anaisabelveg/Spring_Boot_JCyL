package es.jcyl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import es.jcyl.persistence.CarritosDAO;

@SpringBootApplication
@EnableFeignClients
public class MicroServicioCarritoEurekaApplication implements CommandLineRunner{
	
	@Autowired
	private CarritosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoEurekaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Para eliminar todos los carritos de anteriores cursos
		//dao.deleteAll();
		
	}

}
