package es.jcyl.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.Link;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import es.jcyl.business.IProductosBS;
import es.jcyl.entities.Producto;
import jakarta.validation.constraints.Digits;

// Metodos estaticos que utilizo para crear el link
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
//@RequestMapping("/api")
@Validated // Necesario para activar las reglas de validacion
public class ProductosREST {
	
	@Value("${server.port}")   // para inyectar valores (tipos primitivos y String)
	private Integer port;
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
					.stream()
					.map(prod -> {
						prod.setPort(port);
						// Crear el link para que aparezca en la lista de productos
						Link link = linkTo(ProductosREST.class).slash("buscar").slash(prod.getID()).withSelfRel();
						prod.add(link);
						return prod;
					})
					.collect(Collectors.toList());				
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") @Digits(integer = 1, fraction = 0) Long id) {
		Producto producto = bs.buscarProducto(id);
		
		// Si no existe ese producto lanzamos una excepcion
		if (producto.getDescripcion() == null) {
			throw new RuntimeException("Ese producto no existe");
		}
		
		producto.setPort(port);
		return producto;
	}
	
	@PostMapping("/nuevo/descripcion/{descripcion}/precio/{precio}")
	public Producto nuevo(@PathVariable String descripcion, @PathVariable double precio) {
		return bs.crearProducto(new Producto(descripcion, precio));
	}
	
	@DeleteMapping("/eliminar/{id}")
	public String eliminar(@PathVariable Long id) {
		return bs.eliminarProducto(id);
	}

}
















