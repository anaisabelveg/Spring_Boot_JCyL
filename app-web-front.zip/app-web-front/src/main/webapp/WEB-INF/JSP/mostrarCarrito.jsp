<%@page import="es.indra.models.Pedido"%>
<%@page import="es.indra.models.Carrito"%>
<%@page import="es.indra.models.Producto"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Insert title here</title>
	</head>
	<body>
		<h1>Contenido del carrito</h1>
		
		<% Carrito carrito = (Carrito) request.getAttribute("carrito"); %>
		
		<h2>User: <%= carrito.getUsuario() %>  </h2>
		<h2>Importe:  <%= carrito.getImporte() %></h2>
		
		<table border="1" align="center">
			<tr>
				<th>ID</th>
				<th>DESCRIPCION</th>
				<th>PRECIO</th>
				<th>CANTIDAD</th>
				<th>ELIMINAR</th>
			</tr>
			
			<% for(Pedido p: carrito.getContenido()){ %>
				<tr>
					<td> <%= p.getProducto().getID() %> </td>
					<td> <%= p.getProducto().getDescripcion() %> </td>
					<td> <%= p.getProducto().getPrecio() %> </td>
					<td> <%= p.getCantidad() %> </td>
					
					<td>
						<a href="sacar?id=<%= p.getProducto().getID() %>&usuario=<%= carrito.getUsuario() %>">
							Sacar del carrito
						</a> 
					</td>
					
				</tr>
			<% } %>
		
		</table>
	</body>
</html>