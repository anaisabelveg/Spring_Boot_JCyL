package es.jcyl.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.jcyl.business.IPedidosBS;
import es.jcyl.models.Pedido;

@RestController
public class PedidosREST {
	
	
	@Autowired // No permite especificar el id del bean a inyectar
	// 1ª solucion @Primary
	// 2ª solucion @Qualifier
	@Qualifier("pedidosBSImplFeign")
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/2/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// http://localhost:8002/saga/descripcion/Lampara/precio/237.95/proveedor/pepe
	@GetMapping("/saga/descripcion/{descripcion}/precio/{precio}/proveedor/{nombre}")
	public String pruebaSaga(@PathVariable String descripcion, @PathVariable double precio, @PathVariable String nombre) {
		return bs.pruebaTransaccion(descripcion, precio, nombre);
	}

}
