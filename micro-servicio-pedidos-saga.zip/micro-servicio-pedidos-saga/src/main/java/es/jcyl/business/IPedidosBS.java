package es.jcyl.business;

import es.jcyl.models.Pedido;

public interface IPedidosBS {
	
	public Pedido crearPedido(Long idProducto, int cantidad);
	
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor);

}
