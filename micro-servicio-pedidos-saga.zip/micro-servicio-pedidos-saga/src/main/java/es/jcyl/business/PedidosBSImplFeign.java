package es.jcyl.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.jcyl.clients.ProductosClienteFeign;
import es.jcyl.clients.ProveedoresClienteFeign;
import es.jcyl.models.Pedido;
import es.jcyl.models.Producto;

@Service
//@Primary  // Damos preferencia en la inyeccion de dependencias
// el nombre o id del bean es el nombre de la clase con la primera letra en minusculas
public class PedidosBSImplFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteFeign clienteFeign;
	
	@Autowired
	private ProveedoresClienteFeign proveedoresClienteFeign;

	@Override
	public Pedido crearPedido(Long idProducto, int cantidad) {
		Producto producto = clienteFeign.buscar(idProducto);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor) {
		
		String mensaje = "";
		Producto producto = null;
		
		try {
			// Damos de alta el producto
			producto = clienteFeign.nuevo(descripcion, precio);
			
			// Damos de alta el proveedor
			proveedoresClienteFeign.altaProveedor(nombreProveedor);
			
			mensaje = "Todo ha ido bien, transacciones completadas";		
		} catch (Exception e) {
			// Deshacer la transaccion, eliminamos el producto
			String msg = clienteFeign.eliminar(producto.getId());
			System.out.println("********* " + msg + " *********");
			
			mensaje = "Transaccion deshecha " + msg;
		}
		
		return mensaje;
	}

}
