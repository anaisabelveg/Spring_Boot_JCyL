package es.indra.business;

import java.util.List;

import es.indra.models.Carrito;
import es.indra.models.Producto;

public interface IGestionBS {
	
	List<Producto> obtenerTodos(String token);
	
	Producto buscar(Long id, String token);
	
	Carrito consultar(String usuario, String token);
	
	Carrito crear(String usuario, String token);
	
	void agregar(Long id, int cantidad, String usuario, String token);
	
	void eliminar(Long id, String usuario, String token);

}
