package es.jcyl.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import feign.FeignException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Igual que con try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos que cada uno capture un tipo de excepcion
	
	// http://localhost:8002/crear/7656777/cantidad/10
	@ExceptionHandler(FeignException.class)
	public ResponseEntity<String> errorIdProducto(FeignException ex){
		System.out.println(ex.getClass() + "----------------------------");
		return new ResponseEntity<String>("ID de producto no valido", HttpStatus.NOT_FOUND);
	}

	// http://localhost:8002/crear//cantidad/10
	@ExceptionHandler(NoResourceFoundException.class)
	public ResponseEntity<String> errorFormato(NoResourceFoundException ex){	
		return new ResponseEntity<String>("ID de producto obligatorio", HttpStatus.BAD_REQUEST);
	}
	
	// http://localhost:8002/crear/hjhjhbjb/cantidad/10
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> error(Exception ex){
		System.out.println(ex.getClass() + "----------------------------");
		return new ResponseEntity<String>("Ha ocurrido un error", HttpStatus.BAD_REQUEST);
	}
}
