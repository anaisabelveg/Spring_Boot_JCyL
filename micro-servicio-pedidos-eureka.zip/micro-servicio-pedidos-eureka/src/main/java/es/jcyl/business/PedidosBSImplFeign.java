package es.jcyl.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.jcyl.clients.ProductosClienteFeign;
import es.jcyl.models.Pedido;
import es.jcyl.models.Producto;

@Service
//@Primary  // Damos preferencia en la inyeccion de dependencias
// el nombre o id del bean es el nombre de la clase con la primera letra en minusculas
public class PedidosBSImplFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long idProducto, int cantidad) {
		Producto producto = clienteFeign.buscar(idProducto);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

}
