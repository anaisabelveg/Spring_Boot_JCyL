package es.jcyl.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.jcyl.models.Pedido;
import es.jcyl.models.Producto;

@Service
public class PedidosBSImplRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long idProducto, int cantidad) {
		// Buscar el producto con ese id en el micro-servicio-productos
//		Producto producto = restTemplate.getForObject(
//				"http://localhost:8001/buscar/{codigo}", Producto.class, idProducto);
		Producto producto = restTemplate.getForObject(
				"http://servicio-productos/buscar/{codigo}", Producto.class, idProducto);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// retornamos
		return pedido;
	}

}
