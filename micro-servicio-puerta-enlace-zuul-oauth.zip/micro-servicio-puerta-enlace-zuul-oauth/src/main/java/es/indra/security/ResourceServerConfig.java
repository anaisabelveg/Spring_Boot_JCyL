package es.indra.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@EnableResourceServer
@Configuration
public class ResourceServerConfig extends ResourceServerConfigurerAdapter{

	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.tokenStore(tokenStore());
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		// Aqui configuramos que peticiones estan permitidas segun el ROLE
		http.authorizeRequests(request -> 
				request.antMatchers("/api/security/oauth/token").permitAll()
					.antMatchers(HttpMethod.GET, "/api/productos/listar").permitAll()
					.antMatchers(HttpMethod.GET, "/api/productos/buscar/**").hasAnyRole("USER","ADMIN")
					.antMatchers("/api/pedidos/**").hasRole("ADMIN")
					.antMatchers("/api/carrito/crear/{usuario}").hasAnyRole("USER","ADMIN")
					.antMatchers("/api/carrito/consultar/**", "/api/carrito/agregar/**", "/api/carrito/eliminar/**").hasRole("ADMIN")			
				);
	}
	
	@Bean
	public JwtTokenStore tokenStore() {
		// Aqui se genera el token JWT
		return new JwtTokenStore(accessTokenConverter());
	}
	
	@Bean
	public JwtAccessTokenConverter accessTokenConverter() {
		// Elegir la clave de cifrado para generar el jwt
		JwtAccessTokenConverter tokenConverter = new JwtAccessTokenConverter();
		tokenConverter.setSigningKey("pepito_12345_aeiou");
		return tokenConverter;
	}
	

}
