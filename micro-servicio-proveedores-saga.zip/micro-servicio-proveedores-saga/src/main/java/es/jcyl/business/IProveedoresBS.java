package es.jcyl.business;

public interface IProveedoresBS {
	
	String crearProveedor(String nombre);

}
