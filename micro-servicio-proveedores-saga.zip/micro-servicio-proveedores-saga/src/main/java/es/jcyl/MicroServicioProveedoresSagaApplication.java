package es.jcyl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicioProveedoresSagaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProveedoresSagaApplication.class, args);
	}

}
