package es.indra.business;

import es.indra.models.Usuario;

public interface IUsuariosBS {
	
	Usuario buscarUsuario(String username);

}
