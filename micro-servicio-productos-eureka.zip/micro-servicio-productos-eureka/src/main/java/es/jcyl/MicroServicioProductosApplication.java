package es.jcyl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.jcyl.persistence.ProductosDAO;

@SpringBootApplication
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired  // Busca en el contenedor un bean de tipo ProductosDAO, lo inyectas
	private ProductosDAO dao;

	// En los proyectos de Spring Boot el metodo main esta dedicado a levantar el contexto de Spring
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	// Este metodo se ejecuta a continuacion del metodo main
	// lo que me garantiza que ya tengo el contenedor con todos los beans dentro
	@Override
	public void run(String... args) throws Exception {
		// Consultar todos los productos
		dao.findAll().stream()
			.forEach(System.out::println);
		System.out.println("---------------------------------------");
		
		dao.findByDescripcion("Raton").stream()
			.forEach(System.out::println);
		System.out.println("---------------------------------------");
		
		dao.findByPrecioBetween(50, 200).stream()
			.forEach(System.out::println);
		System.out.println("---------------------------------------");
		
		dao.findByPrecioBetweenOrderByDescripcion(50, 200).stream()
			.forEach(System.out::println);
		System.out.println("---------------------------------------");
		
		dao.findByPrecioBetweenOrderByDescripcionDesc(50, 200).stream()
			.forEach(System.out::println);
		System.out.println("---------------------------------------");
		
		dao.miQuery(100).stream()
			.forEach(System.out::println);
		System.out.println("---------------------------------------");
		
	}

}
