package es.jcyl.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.jcyl.business.IProductosBS;
import es.jcyl.entities.Producto;

@RestController
//@RequestMapping("/api")
public class ProductosREST {
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos();
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) {
		return bs.buscarProducto(id);
	}

}
