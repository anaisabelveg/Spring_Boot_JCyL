package es.jcyl.business;

import java.util.List;

import es.jcyl.entities.Producto;

public interface IProductosBS {
	
	List<Producto> consultarTodos();
	
	Producto buscarProducto(Long id);

}
