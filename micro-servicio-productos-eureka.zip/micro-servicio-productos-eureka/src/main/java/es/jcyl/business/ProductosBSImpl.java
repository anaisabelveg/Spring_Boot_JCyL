package es.jcyl.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.jcyl.entities.Producto;
import es.jcyl.persistence.ProductosDAO;

/*
 * En Spring cualquier clase anotada con una de estas 4 anotaciones, se reconoce como un bean de Spring:
 * 			@Repository; repositorios de datos, dao, erp, ldap, ....etc
 * 			@Controller; controladores de Spring MVC
 * 			@Service; servicios, logica de negocio, business, ....
 * 			@Component; cuando la clase no es ninguna de las anteriores
 * */

@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired  // Busca en el contenedor un bean de tipo ProductosDAO, lo inyectas
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
