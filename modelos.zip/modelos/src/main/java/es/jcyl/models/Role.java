package es.jcyl.models;

import java.io.Serializable;

public class Role implements Serializable {

	private Long id;
	private String nombre;

	public Role() {
		// TODO Auto-generated constructor stub
	}

	public Role(String nombre) {
		super();
		this.nombre = nombre;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Role [id=" + id + ", nombre=" + nombre + "]";
	}

}
