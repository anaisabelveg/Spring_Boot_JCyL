package es.jcyl.models;

public class Producto {

	private Long id;
	private String descripcion;
	private double precio;
	private Integer port;

	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(Long id, String descripcion, double precio, Integer port) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.precio = precio;
		this.port = port;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + ", port=" + port + "]";
	}

}
