package es.jcyl.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import es.jcyl.entities.Usuario;

// Expongo el dao como un servicio rest
@RepositoryRestResource(path = "usuarios")
public interface UsuariosDAO extends JpaRepository<Usuario, Long>{

	// http://localhost:8005/usuarios/search/buscar-username?username=juan
	@RestResource(path = "buscar-username")
	public Usuario findByUsername(@Param("username") String username);
}
